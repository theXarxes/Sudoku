package sudoku;

public class JDBCException extends DaoException{
    public JDBCException() {
    }

    public JDBCException(String message) {
        super(message);
    }

    public JDBCException(String message, Throwable cause) {
        super(message, cause);
    }

    public JDBCException(Throwable cause) {
        super(cause);
    }

}
