package sudoku;

public interface SudokuSolver {

    void solve(SudokuBoard board);
}
