package sudoku;

public interface Observer {
    void update();
}
